package com.cg.test;

import static org.junit.Assert.assertTrue;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.service.ApplicantService;
import com.cg.service.ApplicantServiceImpl;
import com.cg.util.MyStringDateUtil;



public class ApplicationTesting {


	ApplicantService applicantService = new ApplicantServiceImpl();
	Application application = new Application();
	
	@Test
	public void testaddapplication() {
		try {
			
			application.setFullName("Vivek");
			application.setDateOfBirth(MyStringDateUtil.fromStringToLocalDate("11-11-1996"));
			application.setHighestQualification("B.Tech");
			application.setMarksObtained(80);
			application.setGoals("Engineer");
			application.setEmailId("vivek@gmail.com");
			application.setScheduledProgramId("MATHS");
			
			
			int status = applicantService.addApplication(application);
			
			boolean test;
			if(status>1)
			{test=true;}
			else
			{test=false;}
			
			Assert.assertTrue(test);
		
		} catch (UASException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testApplicationStatus() throws UASException
	{
		String status = applicantService.applicationStatus(181);
		System.out.println(status);
		Assert.assertEquals("APPLIED", status);
	}
	
//	@Test
//	public void testApplicationStatus2() throws UASException
//	{
//		String status = applicantService.applicationStatus(19);
//		System.out.println(status);
//		Assert.assertEquals(null, status);
//	}
	
	@Test
	public void testApplicationStatus3() throws UASException
	{
		String status = applicantService.applicationStatus(19);
		System.out.println(status);
		Assert.assertNotNull(status);
	}
	
	@Test
	public void testGetScheduledPrograms() throws UASException
	{
		List<ProgramScheduled> status = applicantService.getAllScheduledPrograms();
		Assert.assertNotNull(status);
	}
	
	@Test
	public void testgetScheduledProgramId() throws UASException
	{
		ArrayList<String> list = applicantService.getScheduledProgramId();
		Assert.assertNotNull(list);
	}
	
}
