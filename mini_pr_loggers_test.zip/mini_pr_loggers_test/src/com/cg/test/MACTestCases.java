package com.cg.test;

import org.junit.jupiter.api.Test;

import com.cg.Exception.UASException;
import com.cg.dao.ApplicationDAO;
import com.cg.dao.ApplicationDAOImpl;
import com.cg.service.MACService;
import com.cg.service.MACServiceImpl;

import junit.framework.Assert;

public class MACTestCases {

	MACService mac = new MACServiceImpl();
	ApplicationDAO app = new ApplicationDAOImpl();

	@Test
	public void TestCase1() throws UASException {
		Assert.assertNotNull(mac.getAllScheduledPrograms());
	}

	@Test
	public void TestCase2() throws UASException {
		Assert.assertNotNull(app.applicationStatus(107));
	}

	@Test
	public void TestCase3() throws UASException {
		mac.updateStatus("APPLIED", 221);
		String status = "APPLIED";
		Assert.assertEquals(status + " Interview Date: Not scheduled", app.applicationStatus(221));
	}

	@Test
	public void TestCase4() throws UASException {
		Assert.assertNotNull(mac.getAllApplications());
	}

	@Test
	public void TestCase7() throws UASException {
		Assert.assertNotNull(mac.getAllApplications());
	}

	@Test
	public void TestCase5() throws UASException {
		Assert.assertNotNull(mac.showApplicationByStatus("ACCEPTED"));
	}

	@Test
	public void TestCase6() throws UASException {
		Assert.assertEquals("ACCEPTED", mac.ReturnStatus(107));
	}
}
