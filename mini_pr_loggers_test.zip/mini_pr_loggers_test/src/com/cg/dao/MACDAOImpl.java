package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.Exception.UASException;
import com.cg.QMapper.MACDAOQMapper;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;
import com.cg.util.DBUtil;
import com.cg.util.LoggerClass;
import com.cg.util.MyStringDateUtil;

public class MACDAOImpl implements MACDAO {

	Connection con;
	PreparedStatement pstmt = null;
	Logger logger=null;

	public MACDAOImpl(){
		logger = LoggerClass.getLogger(this.getClass());
	}

	public List<ProgramScheduled> getAllScheduledPrograms() throws UASException {
		List<ProgramScheduled> programScheduledList = new ArrayList<>();

		try {
			con = DBUtil.getConnection();
			logger.info("Connection established to the Database");
			pstmt = con.prepareStatement(MACDAOQMapper.SELECT_ALL_PS);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				ProgramScheduled programScheduled = new ProgramScheduled();

				programScheduled.setScheduledProgramId(resultSet.getString(1));
				programScheduled.setProgramName(resultSet.getString(2));
				programScheduled.setLocation(resultSet.getString(3));
				programScheduled.setStartDate(resultSet.getDate(4));
				programScheduled.setEndDate(resultSet.getDate(5));
				programScheduled.setSessionsPerWeek(resultSet.getInt(6));
				programScheduledList.add(programScheduled);
			}
		} catch (SQLException | IOException e) {
			logger.error("Exception occured while retrieving all Programs");
			throw new UASException("Exception occured while retrieving all Programs");
		}
		logger.info("All Programs scheduled are returned ");
		return programScheduledList;
	}

	@Override
	public String updateStatus(String status, int id) throws UASException {
		int result = 0;
		try {
			con = DBUtil.getConnection();
			logger.info("Connection established to the Database");
			pstmt = con.prepareStatement(MACDAOQMapper.UPDATE_STATUS);
			pstmt.setString(1, status);
			pstmt.setInt(2, id);
			result = pstmt.executeUpdate();
		} catch (SQLException | IOException e) {
			logger.error("Exception occured while executing Update command");
			throw new UASException("Exception occured while executing Update command");
			
		}
		if (result > 0) {
			logger.info("Status is updated and returned ");
			return status;
		} else {
			return null;
		}

	}

	@Override
	public int setInterviewDate(LocalDate date, int id) throws UASException {
		int result = 0;
		java.sql.Date sqlDate = java.sql.Date.valueOf(date);
		try {
			con = DBUtil.getConnection();
			logger.info("Connection established to the Database");
			pstmt = con.prepareStatement(MACDAOQMapper.SET_INTERVIEW);
			pstmt.setDate(1, sqlDate);
			pstmt.setInt(2, id);
			result = pstmt.executeUpdate();
		} catch (SQLException | IOException e) {
			logger.error("Exception occured while setting Interview Date command");
			throw new UASException("Exception occured while setting Interview Date command");
		}
		logger.info("Interview Date is set");
		return result;
	}

	@Override
	public List<Application> showApplicationByStatus(String status) throws UASException {

		List<Application> applicantList = new ArrayList<Application>();
		try {
			con = DBUtil.getConnection();
			logger.info("Connection established to the Database");
			pstmt = con.prepareStatement(MACDAOQMapper.APPLICANT_BY_STATUS);
			pstmt.setString(1, status);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				if (resultSet.getDate(10) == null) {
					applicantList.add(new Application(resultSet.getInt(1), resultSet.getString(2),
							MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)), resultSet.getString(4),
							resultSet.getInt(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8),
							resultSet.getString(9)));
				} else {
					applicantList.add(new Application(resultSet.getInt(1), resultSet.getString(2),
							MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)), resultSet.getString(4),
							resultSet.getInt(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8),
							resultSet.getString(9), MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(10))));
				}
			}
		} catch (SQLException | IOException e) {
			logger.error("Exception occured while retrieving applications by status");
			throw new UASException("Exception occured while retrieving applications by status");
		}
		logger.info("Applications are retruned using status");
		return applicantList;
	}

	@Override
	public List<Application> getAllApplications() throws UASException {
		List<Application> list = new ArrayList<Application>();
		try {
			con = DBUtil.getConnection();
			logger.info("Connection established to the Database");
			pstmt = con.prepareStatement(MACDAOQMapper.ALL_APPLICATIONS);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				if (resultSet.getDate(10) == null) {
					list.add(new Application(resultSet.getInt(1), resultSet.getString(2),
							MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)), resultSet.getString(4),
							resultSet.getInt(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8),
							resultSet.getString(9)));
				} else {
					list.add(new Application(resultSet.getInt(1), resultSet.getString(2),
							MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(3)), resultSet.getString(4),
							resultSet.getInt(5), resultSet.getString(6), resultSet.getString(7), resultSet.getString(8),
							resultSet.getString(9), MyStringDateUtil.fromSqlToLocalDate(resultSet.getDate(10))));
				}
			}
		} catch (SQLException | IOException e) {
			logger.error("Exception occured while retrieving all applications");
			throw new UASException("Exception occured while retrieving all applications");
		}
		logger.info("All applications are returned");
		return list;
	}

	@Override
	public String ReturnStatus(int id) throws UASException {
		String status = null;
		String qry = "SELECT STATUS FROM APPLICATION WHERE APPLICATION_ID=?";
		try {
			con = DBUtil.getConnection();
			logger.info("Connection established to the Database");
			pstmt = con.prepareStatement(MACDAOQMapper.STATUS_usingID);
			pstmt.setInt(1, id);
			ResultSet resultSet = pstmt.executeQuery();
			resultSet.next();
			status = resultSet.getString(1);
		} catch (SQLException | IOException e) {

			logger.error("Exception occured while retrieving status by Id");
			throw new UASException("Exception occured while retrieving status by Id");
		}
		logger.info("Status is returned by Id");
		return status;
	}

}
