 package com.cg.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramOffered;
import com.cg.dto.ProgramScheduled;

public interface AdminDAO {

	boolean checkLogin(String loginId, String password) throws UASException;
	void addProgram(ProgramOffered obj) throws UASException ;
	void deleteProgram(String programName) throws UASException;
	void scheduleProgram(ProgramScheduled obj) throws UASException;
	ArrayList<ProgramScheduled> getScheduledProgram(Date startDate, Date endDate) throws UASException;
	ArrayList<Application> getStatus(String status) throws UASException;
	ArrayList<String> getProgramsOffered() throws UASException;
	ArrayList<ProgramOffered> getProgramsOfferedDetails() throws UASException;

}
