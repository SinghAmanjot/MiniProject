package com.cg.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public interface MACDAO {

	public List <ProgramScheduled> getAllScheduledPrograms()throws UASException;
	public String updateStatus(String status,int id)throws UASException;
	public int setInterviewDate(LocalDate date,int id)throws UASException;
	public List<Application> showApplicationByStatus(String status)throws UASException;
	public List<Application> getAllApplications()throws UASException;
	public String ReturnStatus(int id)throws UASException;
}
