package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.Exception.UASException;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

public interface ApplicantService {

	List <ProgramScheduled> getAllScheduledPrograms() throws UASException;
	int addApplication(Application applicant) throws UASException;
	String applicationStatus(int ID) throws UASException;
	public ArrayList<String> getScheduledProgramId() throws UASException;
	public  boolean isValidName(String applicantName);
	public  boolean isValidDob(String  localDate);
	public  boolean isValidGoals(String goals);
	public  boolean isValidMarks(int marks);
	public  boolean isValidEmailId(String email);
	public boolean isValidScheduleProgId(String scheduleProgId) throws UASException ;
}
