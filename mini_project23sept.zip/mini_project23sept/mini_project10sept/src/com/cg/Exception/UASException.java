package com.cg.Exception;

public class UASException extends Exception {
	public UASException(String msg){
		super(msg);
	}

	public UASException() {
		super();		
	}

	public UASException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);		
	}

	public UASException(String message, Throwable cause) {
		super(message, cause);		
	}

	public UASException(Throwable cause) {
		super(cause);		
	}	
}
