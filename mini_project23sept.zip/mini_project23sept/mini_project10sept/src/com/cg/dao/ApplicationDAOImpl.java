package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.QMapper.ApplicationQMapper;
import com.cg.dto.Application;
import com.cg.dto.ProgramScheduled;

import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class ApplicationDAOImpl implements ApplicationDAO{
	
	Connection con=null;

	Logger logger = null;
	
	public ApplicationDAOImpl() {
		logger = Logger.getLogger(ApplicationDAOImpl.class);
		PropertyConfigurator.configure("C:\\Users\\amanjosi\\Desktop\\mini_project_files\\mini_project20sept\\mini_project10sept\\log4j.properties");
	}

	
	/*******************************************************************************************************
	 - Function Name	:	addApplication()
	 - Input Parameters	:	Applicant
	 - Return Type		:	Integer
	 - Author			:	CAPGEMINI
	 - Creation Date	:	12/09/2019
	 - Description		:	adding applicant details to database
	 ********************************************************************************************************/
	@Override
	public int addApplication(Application applicant) {
		int applicationId = 0;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		PreparedStatement appIdStatement = null;
		
		if (applicant != null) {
			
			try {
				logger.info("Inserting applicant details stated ");
				
				java.sql.Date sqlDOB = MyStringDateUtil.fromLocalToSqlDate(applicant.getDateOfBirth());
				con= DBUtil.getConnection();
				pstmt = con.prepareStatement(ApplicationQMapper.INSERT);
				pstmt.setString(1, applicant.getFullName());
				pstmt.setDate(2, sqlDOB);
				pstmt.setString(3, applicant.getHighestQualification());
				pstmt.setInt(4, applicant.getMarksObtained());
				pstmt.setString(5, applicant.getGoals());
				pstmt.setString(6, applicant.getEmailId());
				pstmt.setString(7, applicant.getScheduledProgramId());
				int count = pstmt.executeUpdate();
				if (count > 0){
					appIdStatement = con.prepareStatement(ApplicationQMapper.CURR_APP_ID);
					rs=appIdStatement.executeQuery();
					if(rs.next())
					{
						applicationId=rs.getInt(1);
						System.out.println("Applicant Id is: "+applicationId);
					}
					logger.info("Inserting applicant details successful ");
				}
				else {				
					System.out.println("Inserting applicant details failed ");
					logger.fatal("Inserting applicant details failed ");
				}				
			}
			catch (SQLException | IOException e) 
			{
				System.out.println(e.getMessage());
				logger.warn(e.getMessage());
			} 			
		}		
		return applicationId;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	getAllScheduledPrograms()
	 - Input Parameters	:	No input parameters
	 - Return Type		:	ArrayList<ProgramScheduled>
	 - Author			:	CAPGEMINI
	 - Creation Date	:	12/09/2019
	 - Description		:	retrieving details of all scheduled programs from database
	 ********************************************************************************************************/
	@Override
	public ArrayList<ProgramScheduled> getAllScheduledPrograms() {		
		ArrayList<ProgramScheduled> programScheduledList = new ArrayList<ProgramScheduled>();
		PreparedStatement pstmt = null;

		logger.info("Function for fetching all schduled program stated ");
		     try {
		    	con= DBUtil.getConnection();
				pstmt = con.prepareStatement(ApplicationQMapper.SELECT_ALL_PS);
				ResultSet rs = pstmt.executeQuery();
				System.out.println("ProgramId\t\t\tProgramName\t\t\tLocation\t\t\tStartDate\t\t\t\tEndDate\t\t\t\tSessionsPerWeek\n");
				while(rs.next()){
					System.out.println(rs.getString(1)+"\t\t\t\t"+rs.getString(2)+"\t\t\t\t"+rs.getString(3)+"\t\t\t\t"+rs.getDate(4)+"\t\t\t\t"+rs.getDate(5)+"\t\t\t\t"+rs.getInt(6));
				}
			} 
		     catch (SQLException | IOException e) {
		    	logger.warn(e.getMessage());
				System.out.println(e.getMessage());
			}
		     
		logger.info("Function for fetching all schduled program successful ");
		return programScheduledList;
	}

	/*******************************************************************************************************
	 - Function Name	:	applicationStatus()
	 - Input Parameters	:	ID of Applicant
	 - Return Type		:	String
	 - Author			:	CAPGEMINI
	 - Creation Date	:	21/09/2019
	 - Description		:	Checking status of applicant from database
	 ********************************************************************************************************/
	@Override
	public String applicationStatus(int ID) {		
		String status = null;
		PreparedStatement pstmt = null;				
		try {
			con= DBUtil.getConnection();
			logger.info("Function for fetching application status stated ");
			pstmt = con.prepareStatement(ApplicationQMapper.STATUS_usingID);
			pstmt.setInt(1,ID);
			ResultSet resultset = pstmt.executeQuery();
			if(resultset.next())
			{
				status = resultset.getString(1);
				logger.info("Function for fetching application status successful ");
			}
		} 
		catch (SQLException | IOException sqlException) {
			logger.warn(sqlException.getMessage());
			System.out.println(sqlException.getMessage());
		} 		
		return status;
	}

	/*******************************************************************************************************
	 - Function Name	:	getScheduledProgramsId()
	 - Input Parameters	:	No input parameters
	 - Return Type		:	ArrayList<String>
	 - Author			:	CAPGEMINI
	 - Creation Date	:	12/09/2019
	 - Description		:	retrieving scheduled program id from database
	 ********************************************************************************************************/
	@Override
	public ArrayList<String> getScheduledProgramId() {
		ArrayList<String> list = new ArrayList<String>();
		try{
			PreparedStatement pst = con.prepareStatement(ApplicationQMapper.SCH_PROGRAM_ID);
			logger.info("Function for fetching scheduled program id stated ");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				list.add(rs.getString(1));
			}	
		}		
		catch(Exception e){
			logger.warn("No Scheduled Programs Found");
			System.out.println("No Scheduled Programs Found");
			System.out.println(e.getMessage());
		}
		
		logger.info("Function for fetching scheduled program id successful ");
		return list;
	}
}